----- WEEKLY AGENDA WEEK-10 RDB&SQL QUESTIONS-3-----

-----1. Report cumulative total turnover by months in each year in pivot table format.

SELECT * 
FROM
	(
	SELECT	distinct YEAR (A.order_date) ord_year, MONTH(A.order_date) ord_month, 
	SUM(quantity*list_price) OVER (PARTITION BY YEAR (A.order_date) ORDER BY YEAR (A.order_date), MONTH(A.order_date)) turnover
	FROM	sale.orders A, sale.order_item B
	WHERE	A.order_id = B.order_id
	) A
PIVOT
	(
	MAX(turnover)
	FOR ord_year
	IN ([2018], [2019],[2020])
	)
PIVOT_TA

---- 2. What percentage of customers purchasing a product have purchased the same product again?----

---ALTERNATIVE-1
WITH T1 AS
(
SELECT  product_id,
SUM(CASE WHEN  counts >=2 THEN 1 ELSE 0 END) AS customer_counts ,
COUNT(customer_id) AS totl_customer
FROM
(
SELECT  DISTINCT  b.product_id,  a.customer_id,
COUNT(a.customer_id) OVER(PARTITION BY b.product_id, a.customer_id ) AS counts
FROM sale.orders a, sale.order_item b
WHERE  a.order_id = b.order_id) AS X
GROUP BY product_id )
SELECT product_id, CAST(1.0*customer_counts/totl_customer AS NUMERIC(3,2)) per_of_cust_pur
FROM T1;

---ALTERNATIVE-2
SELECT	soi.product_id,
		CAST(1.0*(COUNT(so.customer_id) - COUNT(DISTINCT so.customer_id))/COUNT(so.customer_id) AS DECIMAL(3,2)) per_of_cust_pur
FROM	sale.order_item soi, sale.orders so
		WHERE	soi.order_id = so.order_id		
GROUP BY soi.product_id;