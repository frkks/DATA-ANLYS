-- CREATING DATABASE

CREATE DATABASE Assignment_2;

-- CREATING TABLE

CREATE TABLE pubcan (
					User_id int,
					Action varchar(255),
					Date varchar(255)
					);

-- INSERT VALUES INTO TABLE

INSERT INTO Assignment_2.dbo.pubcan (User_id, Action, Date)

VALUES

(1,'Start','1-1-20'),
(1,'Cancel','1-2-20'),
(2,'Start','1-3-20'),
(2,'Publish','1-4-20'),
(3,'Start','1-5-20'),
(3,'Cancel','1-6-20'),
(1,'Start','1-7-20'),
(1,'Publish','1-8-20')

SELECT *
FROM pubcan

-- SOLUTION WITH CREATING VIEW AND USING CAST () FUNCTION

CREATE VIEW View_Ass_2 AS

SELECT	User_id, Start, Publish, Cancel
FROM (
	SELECT
			User_id,
			SUM(CASE WHEN Action = 'Start' THEN 1 ELSE 0 END) AS Start,
			SUM(CASE WHEN Action = 'Publish' THEN 1 ELSE 0 END) AS Publish,
			SUM(CASE WHEN Action = 'Cancel' THEN 1 ELSE 0 END) AS Cancel
	FROM pubcan
	GROUP BY User_id
	) AS A
;

SELECT
		User_id,
		CAST((1.0 * Publish / Start) AS NUMERIC(2,1)) AS 'Publish_rate',
		CAST((1.0 * Cancel / Start) AS NUMERIC(2,1)) AS 'Cancel_rate'
FROM View_Ass_2



-- SOLUTION WITH THE SAME VIEW AND USING CONVERT () FUNCTION

SELECT
		User_id,
		CONVERT(NUMERIC(2,1), (1.0 * Publish / Start)) AS 'Publish_rate',
		CONVERT(NUMERIC(2,1), (1.0 * Cancel / Start)) AS 'Cancel_rate'
FROM View_Ass_2



-- SOLUTION WITH CREATING TABLE WITH SELECT INTO STATEMENT AND USING CAST () FUNCTION

SELECT
		User_id,
		SUM(CASE WHEN Action = 'Start' THEN 1 ELSE 0 END) AS Start,
		SUM(CASE WHEN Action = 'Publish' THEN 1 ELSE 0 END) AS Publish,
		SUM(CASE WHEN Action = 'Cancel' THEN 1 ELSE 0 END) AS Cancel
INTO pubcanrate
FROM pubcan
GROUP BY User_id

SELECT
		User_id,
		CAST((1.0 * Publish / Start) AS NUMERIC(2,1)) AS 'Publish_rate',
		CAST((1.0 * Cancel / Start) AS NUMERIC(2,1)) AS 'Cancel_rate'
FROM pubcanrate



-- SOLUTION WITH USING ABOVE TABLE AND USING STR () FUNCTION

SELECT
		User_id,
		STR(1.0 * Publish / Start, 4, 2) AS 'Publish_rate',
		STR(1.0 * Cancel / Start, 4, 2) AS 'Cancel_rate'
FROM pubcanrate


---Nesrin Hoca
select [user_id],
 cast(1.0*sum (case when [action] = 'Publish' then 1 else 0 end)
 /sum(case when [action]= 'Start' then 1 else 0 end) as numeric (2,1)) as  Publish_rate ,
 cast(1.0*sum (case when [action]= 'Cancel'  then 1 else 0 end) /
 sum(case when [action]= 'Start' then 1 else 0 end) as numeric (2,1)) as Cancel_rate
 from pubcan
 group by [user_id]